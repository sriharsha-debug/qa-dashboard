# QA Dashboard Automation

Playwright script that visits pages on a target project, looks for bugs
(broken links, console errors, broken images, forms with no action, dead
links), and logs each one straight into your QA Dashboard's Supabase
`bugs` table — so it shows up in the dashboard's Bugs tab automatically.

## What it checks

- **Console/JS errors** — anything logged as an error while the page runs
- **Broken links / failed requests** — any network request that returns 4xx/5xx
- **Broken images** — `<img>` tags that fail to render
- **Dead links** — `<a href="#">`, empty `href`, or `javascript:void(0)`
- **Forms with no action** — a form with no `action` attribute and no inline `onsubmit` (flagged for manual review, since JS-driven submits are common and not a bug by themselves)

This is a heuristic scanner, not a full test suite — it's meant to catch
obvious issues quickly. Some findings (like the "no action" form check)
are worth a manual look rather than treated as confirmed bugs.

## Setup (in VS Code)

1. Open this `qa-automation` folder in VS Code (`File → Open Folder`).
2. Open a terminal in VS Code (`` Ctrl+` ``) and run:
   ```bash
   npm install
   npm run install-browsers
   ```
3. Copy the env file and fill in your values:
   ```bash
   cp .env.example .env
   ```
   Edit `.env`:
   - `SUPABASE_URL` / `SUPABASE_ANON_KEY` — already filled in from your dashboard's `public/config.js`, double check they match.
   - `SUPABASE_EMAIL` / `SUPABASE_PASSWORD` — the same login you use for the dashboard.
   - `PROJECT_NAME` — must exactly match an existing project's name on your dashboard's Projects tab (this script logs bugs against it, it doesn't create projects).
   - `BASE_URL` — the site/app you want scanned.
   - `PAGES` — optional. Leave blank to auto-discover same-site links from the homepage, or list specific paths like `/login,/dashboard,/settings`.

## Run it

```bash
npm run scan
```

Or headed (watch the browser do it):
```bash
npm run scan:headed
```

You'll see console output for each page scanned, then a summary of bugs
logged. Open your dashboard's Bugs tab under Project Details for the
project you set in `PROJECT_NAME` — the new bugs will be there with
`reported_by: "QA Automation"`, status `Open`, and details filled in
(steps to reproduce, expected/actual result, etc.) where relevant.

## Auto-add bugs/projects from a notepad file

Instead of (or alongside) the scanner above, you can just write bugs and
project details in a plain text file in Notepad (or any editor), and a
background watcher will pick them up and save them to the dashboard
automatically every time you save the file.

### Setup

1. Copy `watcher/qa-notes-template.txt` to wherever you like — e.g. your
   Desktop — and rename it if you want (e.g. `qa-notes.txt`). Open it in
   Notepad and keep it open.
2. In `.env`, set `NOTES_FILE_PATH` to the full path of that file, e.g.:
   ```
   NOTES_FILE_PATH=C:\Users\you\Desktop\qa-notes.txt
   ```
3. In VS Code's terminal, run:
   ```bash
   npm run watch-notes
   ```
   Leave this running in the background. It signs into Supabase once, then
   watches the file.

### Writing entries

Write blocks like this in your notepad file, then save (Ctrl+S):

```
### BUG
Project: My Project
Title: Login button not working
Page: Login
Severity: High
Description: Clicking login does nothing
Steps: Open login page. Click Login.
Expected: User logs in
Actual: Nothing happens
### END
```

```
### PROJECT
Name: My Project
Status: In Progress
StartDate: 2026-08-01
ProjectManager: John
Bugsheet: https://docs.google.com/...
### END
```

The moment you save, the terminal running `npm run watch-notes` will show
what it found and synced. `PROJECT` blocks create a new project or update
it if a project with that exact name already exists. `BUG` blocks need a
`Project:` that already exists on the dashboard (add the `PROJECT` block
first, or create it manually, if it's brand new) — the bug is logged as
`Open`, `reported_by: "Notes Import"`.

Keep adding new blocks below old ones and keep saving — already-synced
blocks are remembered (in `state/processed-blocks.json`) so they won't be
re-added. Only `Title` (bugs) and `Name` (projects) are required; leave
other fields blank if you don't have that info yet.

If a block fails (e.g. bug references a project that doesn't exist yet),
it's *not* marked as processed — fix it and save again and it'll retry.

## Test case generation via the automation script (no manual button)

The Test Execution tab now also has a script-driven panel — separate
from the original manual "Copy prompt / Open Claude.ai" one, which is
still there if you prefer it. This new one skips clicking anything to
open Claude.ai:

1. Select a project (top of the Test Execution tab, as usual).
2. In the new "Generate test cases via automation script" box, paste
   your requirements/document text, click **Save document**.
3. `npm run watch-dashboard` picks it up within a few seconds, copies
   the same detailed test-case prompt to your clipboard, and opens
   Claude.ai for you automatically.
4. Paste it in, get the reply, copy it, paste it into the "AI reply"
   box right below, click **Save reply**.
5. The script parses it and adds the test cases straight to that
   project — check the Test Execution tab.

Requires `migration-v28.sql` (adds three columns to `quick_notes`).
Same one-at-a-time rule applies — bugs and test cases each track their
own pending AI request separately, so a pending bug reply and a pending
test-case reply can both be outstanding at once without conflicting,
but you can't queue two test-case documents back to back.

## Dashboard-embedded notes (no local files at all)

If you'd rather not use a separate Notepad file, the dashboard itself has
two boxes for this — on the **Bugs tab**: "Quick Notes" (where you write
`### BUG` / `### PROJECT` blocks, same format as everywhere else) and
"AI reply" (where you paste Claude's reply). Requires running
`migration-v27.sql` once in Supabase's SQL Editor to create the
`quick_notes` table it uses.

Run this instead of `npm run watch-notes`:
```bash
npm run watch-dashboard
```

It signs into Supabase and **polls your account's Quick Notes box** every
few seconds (no local file, no `NOTES_FILE_PATH`/`AI_REPLY_FILE_PATH`
needed for this mode) instead of watching a file. Workflow:

1. On the dashboard's Bugs tab, type a block into "Quick Notes", click
   **Save notes**.
2. Within a few seconds, the terminal running `npm run watch-dashboard`
   picks it up. If the bug has full details already, it's logged right
   away. If details are missing (and `ENABLE_AI_AUTOFILL` is off), it
   copies a prompt to your clipboard and opens Claude.ai automatically —
   same as the free-flow described above.
3. Paste Claude's reply into the dashboard's "AI reply" box, click
   **Save reply** — the script finishes creating the bug(s).

Everything else — multi-title blocks, project name matching, one
AI-request-at-a-time — works exactly the same as the file-based version.
The two modes track "already processed" blocks separately, so you can
use either one (or switch between them) without double-logging anything.
`ENABLE_AI_AUTOFILL=true` (paid) works here too, if you'd rather skip
the clipboard step entirely.

## Multiple bugs in one block

You can put several `Title:` lines under one `### BUG` block to log
several bugs at once, sharing the same `Project:` and any other fields
you give at the block level:

```
### BUG
Project: Project K
Severity: High
Harsha title 4
Title: Harsha title 4
Title: Harsha title 5
Title: Harsha title 6
### END
```

This creates three bugs, all under "Project K", all `Severity: High`
(since that's shared across the block). Any field you *don't* set at the
block level — description, steps, expected/actual result, or severity/module
if you skip those too — falls back to AI autofill per-title if enabled,
or a blank/default otherwise.

If one title in a multi-title block fails (e.g. a typo makes the project
lookup fail — though that only happens if the whole block's `Project:` is
wrong, which fails the whole block), it's logged as an error and the rest
still get synced. The block is marked as done either way, so fix any
failed one manually on the dashboard rather than re-editing the note.

## Free AI help (no API key, no cost)

If you don't want to pay for the API, set `FREE_AI_FLOW=true` and
`AI_REPLY_FILE_PATH=` (a file path, e.g. `C:\Users\you\Desktop\qa-ai-reply.txt`)
in `.env` instead of `ENABLE_AI_AUTOFILL`. This is semi-automatic — a
background script can't drive Claude.ai's chat for you (that's not
something Claude.ai's terms allow to automate), so there's one small
manual step, but everything else is automatic:

1. You save a `BUG` block with a title but missing details.
2. The watcher **automatically copies a ready prompt to your clipboard
   and opens a new Claude.ai tab** for you.
3. You paste (Ctrl+V) into Claude.ai, send it, copy the reply.
4. Paste the reply into the file at `AI_REPLY_FILE_PATH` (it'll have
   instructions and a line already in it — paste below the line), save.
5. The watcher reads that, matches it back to your bug title(s), and
   logs the finished bug(s) to your dashboard automatically.

Only one AI request can be "in flight" at a time — if you save another
title-only bug while one is still waiting on a reply, the watcher tells
you to finish the current one first (paste its reply and save) before
it'll start a new one. This avoids mixing up which reply belongs to
which bug.

This works cross-platform: Windows (`clip`/`start`), macOS
(`pbcopy`/`open`), and Linux (`xclip`/`xsel` + `xdg-open` — install
`xclip` if you're on Linux and don't already have a clipboard tool).

## AI autofill (paid — fully automatic)

Set `ENABLE_AI_AUTOFILL=true` and add your own `ANTHROPIC_API_KEY` in
`.env` (get one at https://console.anthropic.com — this is separate from
a claude.ai login and is billed per use) to have Claude fill in any bug
field you leave blank, based only on the title:

```
### BUG
Project: Project K
Title: Search results pagination breaks on page 3
### END
```

With autofill on, this one line becomes a full bug report with a guessed
severity, module, description, steps to reproduce, and expected/actual
result. Treat AI-filled fields as a starting draft — it's guessing from
the title alone, it doesn't know your actual app, so review anything
that matters before treating it as accurate. Any field you *do* provide
in the note is left exactly as you wrote it and never overwritten by AI.

## Using this with your team

Each teammate needs their own copy of this `qa-automation` folder with
Node.js installed, their own `.env` (their own dashboard email/password,
their own `NOTES_FILE_PATH` pointing at their own notes file), and their
own `npm run watch-notes` running. Bugs/projects are tied to whoever's
logged in — your database's row-level security means:
- A regular team member only sees their own bugs/projects on the dashboard.
- A "team leader" account sees everyone's.

If you want one shared notes file that anyone on the team can write to
(rather than everyone having their own), that's possible too — say the
word and I'll help set that up, but it means only one person's
`watch-notes` process should be running against that shared file at a
time, to avoid two people's watchers double-processing the same saves.

## Notes / limitations

- **No dedup yet.** Running the scan twice on an unchanged site will log
  duplicate bugs. If you want to run this on a schedule, ask me and I'll
  add a check that skips a finding if an open bug with the same title +
  page already exists.
- **Same-origin only.** The auto-discovery crawler only follows links on
  the same domain as `BASE_URL`, one level deep from the homepage, capped
  by `MAX_PAGES`.
- **Needs a real login.** Because the dashboard's Row Level Security
  requires an authenticated user, the script signs in with the email/password
  in `.env` — never commit that file (it's already git-ignored).
- **Not exhaustive.** This won't catch visual regressions, logic bugs, or
  anything that requires actually interacting with app-specific flows
  (filling forms, multi-step wizards, etc.). Tell me more about the
  specific project once you're ready and I can add targeted checks
  (e.g. login flow, specific button clicks, form submissions with real
  data) on top of this base scanner.
