require('dotenv').config();
const { test } = require('@playwright/test');
const { getAuthedSupabase, getProjectId } = require('../lib/supabaseClient');
const { reportBug } = require('../lib/reportBug');

const BASE_URL = process.env.BASE_URL;
const EXPLICIT_PAGES = (process.env.PAGES || '')
  .split(',')
  .map((p) => p.trim())
  .filter(Boolean);
const MAX_PAGES = parseInt(process.env.MAX_PAGES || '15', 10);

function sameOrigin(href, base) {
  try {
    const u = new URL(href, base);
    return u.origin === new URL(base).origin ? u.href.split('#')[0] : null;
  } catch {
    return null;
  }
}

async function discoverLinks(page, baseUrl, max) {
  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  const hrefs = await page.$$eval('a[href]', (as) => as.map((a) => a.getAttribute('href')));
  const found = new Set([baseUrl]);
  for (const href of hrefs) {
    const resolved = sameOrigin(href, baseUrl);
    if (resolved) found.add(resolved);
    if (found.size >= max) break;
  }
  return Array.from(found).slice(0, max);
}

async function scanPage(page, url, findings) {
  const consoleErrors = [];
  const failedRequests = [];

  const onConsole = (msg) => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  };
  const onPageError = (err) => consoleErrors.push(err.message);
  const onResponse = (res) => {
    if (res.status() >= 400) {
      failedRequests.push(`${res.status()} ${res.url()}`);
    }
  };

  page.on('console', onConsole);
  page.on('pageerror', onPageError);
  page.on('response', onResponse);

  try {
    await page.goto(url, { waitUntil: 'networkidle', timeout: 30_000 });
  } catch (err) {
    findings.push({
      title: `Page failed to load: ${url}`,
      page: url,
      severity: 'Critical',
      module: 'Automated Scan',
      description: 'Navigation did not complete within the timeout.',
      actualResult: err.message,
      expectedResult: 'Page loads successfully.',
    });
    page.off('console', onConsole);
    page.off('pageerror', onPageError);
    page.off('response', onResponse);
    return;
  }

  // Broken images
  const brokenImages = await page.$$eval('img', (imgs) =>
    imgs
      .filter((img) => img.complete && img.naturalWidth === 0)
      .map((img) => img.src || img.getAttribute('src') || '(no src)')
  );
  if (brokenImages.length) {
    findings.push({
      title: `${brokenImages.length} broken image(s) on ${url}`,
      page: url,
      severity: 'Medium',
      module: 'Automated Scan',
      subModule: 'Images',
      description: `Image failed to render (0 natural width): ${brokenImages.slice(0, 5).join(', ')}`,
      expectedResult: 'All images load correctly.',
      actualResult: `${brokenImages.length} image(s) failed to load.`,
    });
  }

  // Dead / non-functional links (href="#", empty href, "javascript:void(0)")
  const deadLinks = await page.$$eval('a', (as) =>
    as
      .filter((a) => {
        const href = (a.getAttribute('href') || '').trim();
        return href === '' || href === '#' || href.toLowerCase().startsWith('javascript:void');
      })
      .map((a) => (a.textContent || '').trim() || '(no text)')
  );
  if (deadLinks.length) {
    findings.push({
      title: `${deadLinks.length} dead/non-functional link(s) on ${url}`,
      page: url,
      severity: 'Low',
      module: 'Automated Scan',
      subModule: 'Links',
      description: `Links with empty/# href and no visible destination: ${deadLinks.slice(0, 5).join(', ')}`,
      expectedResult: 'Links point to a real destination or have a working click handler.',
      actualResult: `${deadLinks.length} link(s) go nowhere.`,
    });
  }

  // Forms with no action and no visible submit handler hint
  const suspectForms = await page.$$eval('form', (forms) =>
    forms
      .filter((f) => !f.getAttribute('action') && !f.onsubmit)
      .map((f) => f.getAttribute('id') || f.getAttribute('name') || '(unnamed form)')
  );
  if (suspectForms.length) {
    findings.push({
      title: `${suspectForms.length} form(s) with no action attribute on ${url}`,
      page: url,
      severity: 'Medium',
      module: 'Automated Scan',
      subModule: 'Forms',
      description: `Forms found with no "action" attribute (may rely on JS submit — verify manually): ${suspectForms.slice(0, 5).join(', ')}`,
      expectedResult: 'Form submits data somewhere on submit.',
      actualResult: 'No action attribute and no inline onsubmit detected.',
    });
  }

  page.off('console', onConsole);
  page.off('pageerror', onPageError);
  page.off('response', onResponse);

  if (consoleErrors.length) {
    findings.push({
      title: `${consoleErrors.length} console/JS error(s) on ${url}`,
      page: url,
      severity: 'High',
      module: 'Automated Scan',
      subModule: 'Console errors',
      description: consoleErrors.slice(0, 5).join('\n---\n'),
      stepsToReproduce: `1. Open ${url}\n2. Open browser dev tools console`,
      expectedResult: 'No errors logged to console.',
      actualResult: `${consoleErrors.length} error(s) logged.`,
    });
  }

  if (failedRequests.length) {
    findings.push({
      title: `${failedRequests.length} failed network request(s) on ${url}`,
      page: url,
      severity: 'High',
      module: 'Automated Scan',
      subModule: 'Broken links / 4xx-5xx',
      description: failedRequests.slice(0, 8).join('\n'),
      expectedResult: 'All requests return a successful status.',
      actualResult: `${failedRequests.length} request(s) returned 4xx/5xx.`,
    });
  }
}

test('scan project and log bugs to dashboard', async ({ page }) => {
  test.setTimeout(10 * 60 * 1000);

  if (!BASE_URL) {
    throw new Error('BASE_URL is not set. Copy .env.example to .env and fill it in.');
  }

  console.log(`\nStarting scan of ${BASE_URL}\n`);

  const pagesToVisit =
    EXPLICIT_PAGES.length > 0
      ? EXPLICIT_PAGES.map((p) => new URL(p, BASE_URL).href)
      : await discoverLinks(page, BASE_URL, MAX_PAGES);

  console.log(`Visiting ${pagesToVisit.length} page(s):`);
  pagesToVisit.forEach((u) => console.log(`  - ${u}`));

  const findings = [];
  for (const url of pagesToVisit) {
    console.log(`\nScanning: ${url}`);
    await scanPage(page, url, findings);
  }

  console.log(`\nScan complete. ${findings.length} potential issue(s) found.\n`);

  if (findings.length === 0) {
    console.log('Nothing to log — no issues found.');
    return;
  }

  console.log('Logging into Supabase...');
  const { supabase, user } = await getAuthedSupabase();
  const projectName = process.env.PROJECT_NAME;
  if (!projectName) throw new Error('PROJECT_NAME is not set in .env.');
  const projectId = await getProjectId(supabase, projectName);

  console.log(`Logging ${findings.length} bug(s) to project "${projectName}"...\n`);
  for (const finding of findings) {
    await reportBug({ supabase, user, projectId, finding });
  }

  console.log('\nDone — check the Bugs tab under Project Details in your dashboard.');
});
