require('dotenv').config();
const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const { getAuthedSupabase } = require('../lib/supabaseClient');
const { parseNotesFile } = require('./parseNotes');
const { handleProjectBlock, handleBugBlock, findProjectIdByName, blockNeedsAi, getSharedBugFields } = require('./handlers');
const { startFreeAiFlow, loadPending, tryFinalizePendingReply, REPLY_FILE_PATH } = require('./freeAiFlow');

const NOTES_FILE_PATH = process.env.NOTES_FILE_PATH;
const STATE_FILE = path.join(__dirname, '..', 'state', 'processed-blocks.json');
const PAID_AI = String(process.env.ENABLE_AI_AUTOFILL || '').toLowerCase() === 'true';
const FREE_AI_FLOW = String(process.env.FREE_AI_FLOW || '').toLowerCase() === 'true';

if (!NOTES_FILE_PATH) {
  console.error('NOTES_FILE_PATH is not set in .env. Point it at your notepad file, e.g.:');
  console.error('  NOTES_FILE_PATH=C:\\Users\\you\\Desktop\\qa-notes.txt   (Windows)');
  console.error('  NOTES_FILE_PATH=/Users/you/Desktop/qa-notes.txt      (Mac)');
  process.exit(1);
}

if (FREE_AI_FLOW && !REPLY_FILE_PATH) {
  console.error('FREE_AI_FLOW=true but AI_REPLY_FILE_PATH is not set in .env. Set it to a file path, e.g.:');
  console.error('  AI_REPLY_FILE_PATH=C:\\Users\\you\\Desktop\\qa-ai-reply.txt');
  process.exit(1);
}

function loadProcessed() {
  try {
    return new Set(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    return new Set();
  }
}

function saveProcessed(set) {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(Array.from(set), null, 2));
}

function markProcessed(blockId) {
  const processed = loadProcessed();
  processed.add(blockId);
  saveProcessed(processed);
}

let supabase, user;
let processing = false;

async function processFile() {
  if (processing) return; // avoid overlapping runs if the file saves twice quickly
  processing = true;
  try {
    if (!fs.existsSync(NOTES_FILE_PATH)) {
      console.log(`Waiting for file to exist: ${NOTES_FILE_PATH}`);
      return;
    }
    const content = fs.readFileSync(NOTES_FILE_PATH, 'utf8');
    const blocks = parseNotesFile(content);
    const processed = loadProcessed();
    const newBlocks = blocks.filter((b) => !processed.has(b.id));

    if (newBlocks.length === 0) {
      console.log('No new BUG/PROJECT blocks since last save.');
      return;
    }

    console.log(`Found ${newBlocks.length} new block(s). Syncing to dashboard...`);

    for (const block of newBlocks) {
      try {
        if (block.type === 'PROJECT') {
          const result = await handleProjectBlock({ supabase, user, fields: block.fields });
          console.log(`✓ Project ${result.action}: ${result.name}`);
          processed.add(block.id);
          continue;
        }

        if (block.type !== 'BUG') continue;

        const needsAi = blockNeedsAi(block.fields);

        // Route through the free clipboard+browser flow only when: fields
        // are actually missing, paid autofill is off, and free-flow is on.
        if (needsAi && FREE_AI_FLOW && !PAID_AI) {
          const pending = loadPending();
          if (pending) {
            console.log(
              `⏳ Still waiting on a previous AI reply (${pending.titles.join(', ')}) — paste it into ${REPLY_FILE_PATH} and save first. This new block will stay pending until then.`
            );
            continue; // do NOT mark processed — will retry next save
          }

          const projectName = block.fields.project;
          let projectId;
          try {
            projectId = await findProjectIdByName(supabase, projectName);
          } catch (err) {
            console.error(`✗ BUG block skipped: ${err.message}`);
            continue;
          }
          if (!projectId) {
            console.error(
              `✗ BUG block skipped: No project named "${projectName}" exists yet. Add a PROJECT block first.`
            );
            continue;
          }

          const shared = getSharedBugFields(block.fields);
          const titles = block.fields.titles || [];
          await startFreeAiFlow({ blockId: block.id, projectId, projectName, titles, shared, supabase });
          continue; // not marked processed — waiting on the reply file
        }

        // Normal path: paid autofill (if enabled), or fields already
        // complete, or no AI configured at all (fields stay blank).
        const { results, errors: bugErrors } = await handleBugBlock({ supabase, user, fields: block.fields });
        for (const r of results) {
          console.log(`✓ Bug logged: "${r.title}" → ${r.project}${r.aiFilled ? ' (AI-filled fields)' : ''}`);
        }
        for (const e of bugErrors) {
          console.error(`✗ Bug "${e.title}" failed: ${e.message}`);
        }
        processed.add(block.id);
      } catch (err) {
        // Don't mark this block processed — it'll retry next save once the note is fixed.
        console.error(`✗ ${block.type} block skipped: ${err.message}`);
      }
    }

    saveProcessed(processed);
  } catch (err) {
    console.error('Error processing notes file:', err.message);
  } finally {
    processing = false;
  }
}

let processingReply = false;
async function processReplyFile() {
  if (processingReply) return;
  processingReply = true;
  try {
    const result = await tryFinalizePendingReply({ supabase, user });
    if (result && result.done) {
      markProcessed(result.blockId);
      console.log('✅ All titles from that AI reply are now logged.\n');
    }
  } catch (err) {
    console.error('Error processing AI reply file:', err.message);
  } finally {
    processingReply = false;
  }
}

async function main() {
  console.log('Logging into Supabase...');
  const auth = await getAuthedSupabase();
  supabase = auth.supabase;
  user = auth.user;
  console.log(`Signed in as ${user.email}`);

  console.log(`Watching: ${NOTES_FILE_PATH}`);
  if (FREE_AI_FLOW) {
    console.log(`Free AI-help flow is ON. Reply file: ${REPLY_FILE_PATH}`);
  }
  console.log('Write a block like:\n');
  console.log('### BUG');
  console.log('Project: My Project');
  console.log('Title: Login button not working');
  console.log('Page: Login');
  console.log('Severity: High');
  console.log('Description: Clicking login does nothing');
  console.log('### END\n');
  console.log('...then save the file. This window will pick it up automatically.\n');

  // process once on startup in case there are unsynced blocks already
  await processFile();
  if (FREE_AI_FLOW) await processReplyFile();

  const watcher = chokidar.watch(NOTES_FILE_PATH, {
    awaitWriteFinish: { stabilityThreshold: 500, pollInterval: 100 },
  });
  watcher.on('change', () => {
    console.log('\nNotes file changed, checking for new entries...');
    processFile();
  });

  if (FREE_AI_FLOW) {
    fs.mkdirSync(path.dirname(REPLY_FILE_PATH), { recursive: true });
    if (!fs.existsSync(REPLY_FILE_PATH)) fs.writeFileSync(REPLY_FILE_PATH, '');
    const replyWatcher = chokidar.watch(REPLY_FILE_PATH, {
      awaitWriteFinish: { stabilityThreshold: 500, pollInterval: 100 },
    });
    replyWatcher.on('change', () => {
      console.log('\nAI reply file changed, checking...');
      processReplyFile();
    });
  }
}

main().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
