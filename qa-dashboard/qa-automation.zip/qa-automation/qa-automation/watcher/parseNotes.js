/**
 * Parses a notes file into blocks like:
 *
 * ### BUG
 * Project: My Project
 * Title: Login button not working
 * Page: Login
 * Severity: High
 * Module: Auth
 * Description: Clicking login does nothing
 * Steps: Open login page. Click Login.
 * Expected: User logs in
 * Actual: Nothing happens
 * ### END
 *
 * ### PROJECT
 * Name: My Project
 * Status: In Progress
 * StartDate: 2026-08-01
 * ProjectManager: John
 * Bugsheet: https://docs.google.com/...
 * ### END
 *
 * Blank lines and extra spacing are fine. Field names are case-insensitive.
 * Each block gets a stable id (hash of its raw text) so the watcher can
 * tell which blocks it has already processed.
 */
const crypto = require('crypto');

function hashBlock(text) {
  return crypto.createHash('sha1').update(text.trim()).digest('hex');
}

function parseFields(bodyLines) {
  const fields = {};
  const titles = [];
  let currentKey = null;
  for (const line of bodyLines) {
    const match = line.match(/^\s*([A-Za-z][A-Za-z ]*)\s*:\s*(.*)$/);
    if (match) {
      const key = match[1].trim().toLowerCase().replace(/\s+/g, '');
      const value = match[2].trim();
      if (key === 'title') {
        // Multiple "Title:" lines in one block = multiple bugs sharing
        // whatever other fields are given in this same block.
        titles.push(value);
        currentKey = null;
      } else {
        currentKey = key;
        fields[key] = value;
      }
    } else if (currentKey && line.trim()) {
      // continuation of a multi-line field
      fields[currentKey] += ' ' + line.trim();
    }
  }
  fields.titles = titles;
  return fields;
}

function parseNotesFile(content) {
  const blocks = [];
  const blockRegex = /###\s*(BUG|PROJECT)[ \t]*\r?\n?([\s\S]*?)###\s*END/gi;
  let m;
  while ((m = blockRegex.exec(content)) !== null) {
    const type = m[1].toUpperCase();
    const raw = m[0];
    const bodyLines = m[2].split('\n');
    const fields = parseFields(bodyLines);
    blocks.push({
      id: hashBlock(raw),
      type,
      fields,
      raw,
    });
  }
  return blocks;
}

module.exports = { parseNotesFile, hashBlock };
