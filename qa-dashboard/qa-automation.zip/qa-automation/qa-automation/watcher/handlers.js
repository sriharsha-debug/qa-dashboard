const { aiFillBugFields } = require('./aiFill');
const { fetchKnowledgeContext } = require('../lib/projectKnowledge');

const VALID_SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];

function pick(fields, ...keys) {
  for (const k of keys) {
    if (fields[k] !== undefined && fields[k] !== '') return fields[k];
  }
  return undefined;
}

async function findProjectIdByName(supabase, name) {
  const { data, error } = await supabase
    .from('projects')
    .select('id')
    .eq('name', name)
    .maybeSingle();
  if (error) throw new Error(`Project lookup failed: ${error.message}`);
  return data ? data.id : null;
}

async function handleProjectBlock({ supabase, user, fields }) {
  const name = pick(fields, 'name');
  if (!name) throw new Error('PROJECT block is missing "Name:" — skipped.');

  const row = {
    owner_id: user.id,
    name,
    status: pick(fields, 'status') || undefined,
    start_date: pick(fields, 'startdate') || undefined,
    end_date: pick(fields, 'enddate') || undefined,
    bugsheet: pick(fields, 'bugsheet') || undefined,
    project_document: pick(fields, 'projectdocument', 'document') || undefined,
    project_manager: pick(fields, 'projectmanager', 'manager') || undefined,
    remarks: pick(fields, 'remarks', 'notes') || undefined,
  };
  // strip undefined so we don't overwrite existing values with blanks
  Object.keys(row).forEach((k) => row[k] === undefined && delete row[k]);

  const existingId = await findProjectIdByName(supabase, name);

  if (existingId) {
    const { error } = await supabase.from('projects').update(row).eq('id', existingId);
    if (error) throw new Error(`Project update failed: ${error.message}`);
    return { action: 'updated', name };
  } else {
    const { error } = await supabase.from('projects').insert(row);
    if (error) throw new Error(`Project insert failed: ${error.message}`);
    return { action: 'created', name };
  }
}

/**
 * Handles a BUG block that may contain one or more "Title:" lines.
 * Every title becomes its own bug row, sharing whatever other fields
 * were given in the block. Any field left blank for a title gets a
 * shot at AI autofill (if enabled) before falling back to a default.
 *
 * Returns { results, errors } — never throws for per-title problems,
 * so one bad title doesn't block the rest. The whole block IS still
 * thrown as an error (and not marked processed) for block-level
 * problems like a missing Project or a project that doesn't exist.
 */
async function handleBugBlock({ supabase, user, fields }) {
  const projectName = pick(fields, 'project');
  const titles = fields.titles || [];
  if (!projectName) throw new Error('BUG block is missing "Project:" — skipped.');
  if (titles.length === 0) throw new Error('BUG block is missing "Title:" — skipped.');

  const projectId = await findProjectIdByName(supabase, projectName);
  if (!projectId) {
    throw new Error(
      `No project named "${projectName}" exists yet. Add a PROJECT block for it first (or create it on the dashboard), then re-save the notes file.`
    );
  }

  const sharedSeverity = pick(fields, 'severity');
  const sharedPage = pick(fields, 'page');
  const sharedModule = pick(fields, 'module');
  const sharedDescription = pick(fields, 'description');
  const sharedSteps = pick(fields, 'steps', 'stepstoreproduce');
  const sharedExpected = pick(fields, 'expected', 'expectedresult');
  const sharedActual = pick(fields, 'actual', 'actualresult');

  const results = [];
  const errors = [];

  const anyNeedsAi = titles.some(() => !sharedDescription || !sharedSteps || !sharedExpected || !sharedActual);
  const knowledgeContext = anyNeedsAi
    ? await fetchKnowledgeContext({ supabase, projectId, focusHint: sharedPage || sharedModule })
    : '';

  for (const title of titles) {
    try {
      const needsAi = !sharedDescription || !sharedSteps || !sharedExpected || !sharedActual;
      const ai = needsAi
        ? await aiFillBugFields({
            title,
            projectName,
            known: {
              severity: sharedSeverity,
              module: sharedModule,
              description: sharedDescription,
              steps_to_reproduce: sharedSteps,
              expected_result: sharedExpected,
              actual_result: sharedActual,
            },
            knowledgeContext,
          })
        : {};

      let severity = sharedSeverity || ai.severity || 'Medium';
      if (!VALID_SEVERITIES.includes(severity)) severity = 'Medium';

      const row = {
        owner_id: user.id,
        project_id: projectId,
        title,
        page: sharedPage || 'Unknown',
        severity,
        status: 'Open',
        description: sharedDescription || ai.description || null,
        module: sharedModule || ai.module || null,
        sub_module: pick(fields, 'submodule') || null,
        steps_to_reproduce: sharedSteps || ai.steps_to_reproduce || null,
        expected_result: sharedExpected || ai.expected_result || null,
        actual_result: sharedActual || ai.actual_result || null,
        reported_by: pick(fields, 'reportedby') || 'Notes Import',
        notes: pick(fields, 'notes') || null,
        developer_status: 'Not Started',
        retest_status: 'Not Retested',
      };

      const { error } = await supabase.from('bugs').insert(row);
      if (error) throw new Error(error.message);
      results.push({ action: 'created', title, project: projectName, aiFilled: needsAi });
    } catch (err) {
      errors.push({ title, message: err.message });
    }
  }

  return { results, errors };
}

function blockNeedsAi(fields) {
  const has = (k) => Boolean(pick(fields, k));
  return !(has('description') && (has('steps') || has('stepstoreproduce')) && (has('expected') || has('expectedresult')) && (has('actual') || has('actualresult')));
}

function getSharedBugFields(fields) {
  return {
    severity: pick(fields, 'severity'),
    page: pick(fields, 'page'),
    module: pick(fields, 'module'),
    subModule: pick(fields, 'submodule'),
    description: pick(fields, 'description'),
    steps: pick(fields, 'steps', 'stepstoreproduce'),
    expected: pick(fields, 'expected', 'expectedresult'),
    actual: pick(fields, 'actual', 'actualresult'),
    notes: pick(fields, 'notes'),
  };
}

module.exports = { handleProjectBlock, handleBugBlock, findProjectIdByName, blockNeedsAi, getSharedBugFields };
