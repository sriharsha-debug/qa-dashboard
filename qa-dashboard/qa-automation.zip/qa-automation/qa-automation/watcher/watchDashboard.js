require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { getAuthedSupabase } = require('../lib/supabaseClient');
const { parseNotesFile } = require('./parseNotes');
const { handleProjectBlock, handleBugBlock, findProjectIdByName, blockNeedsAi, getSharedBugFields } = require('./handlers');
const { fetchKnowledgeContext } = require('../lib/projectKnowledge');

const STATE_FILE = path.join(__dirname, '..', 'state', 'processed-blocks-dashboard.json');
const PENDING_FILE = path.join(__dirname, '..', 'state', 'pending-ai-block-dashboard.json');
const PAID_AI = String(process.env.ENABLE_AI_AUTOFILL || '').toLowerCase() === 'true';
const POLL_MS = parseInt(process.env.DASHBOARD_POLL_MS || '1500', 10);
const VALID_SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];

function copyToClipboard(text) {
  const platform = process.platform;

  if (platform === 'darwin') {
    return new Promise((resolve, reject) => {
      const proc = exec('pbcopy', (err) => (err ? reject(err) : resolve()));
      proc.stdin.write(text);
      proc.stdin.end();
    });
  }

  if (platform === 'win32') {
    return new Promise((resolve, reject) => {
      const proc = exec('clip', (err) => (err ? reject(err) : resolve()));
      proc.stdin.write(text);
      proc.stdin.end();
    });
  }

  // Linux and others: try xclip, then fall back to xsel.
  return new Promise((resolve, reject) => {
    const tryXclip = () =>
      new Promise((res, rej) => {
        const proc = exec('xclip -selection clipboard', (err) => (err ? rej(err) : res()));
        proc.stdin.write(text);
        proc.stdin.end();
      });
    const tryXsel = () =>
      new Promise((res, rej) => {
        const proc = exec('xsel --clipboard --input', (err) => (err ? rej(err) : res()));
        proc.stdin.write(text);
        proc.stdin.end();
      });
    tryXclip()
      .then(resolve)
      .catch(() =>
        tryXsel()
          .then(resolve)
          .catch(() => reject(new Error('No clipboard tool found (tried xclip, xsel). Install one, e.g. `sudo apt install xclip`.')))
      );
  });
}

function openBrowser(url) {
  const platform = process.platform;
  const cmd =
    platform === 'darwin' ? `open "${url}"` :
    platform === 'win32' ? `start "" "${url}"` :
    `xdg-open "${url}"`;

  exec(cmd, (err) => {
    if (err) console.warn(`Could not auto-open a browser tab: ${err.message}. Open ${url} manually.`);
  });
}

function loadProcessed() {
  try {
    return new Set(JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')));
  } catch {
    return new Set();
  }
}
function saveProcessed(set) {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  fs.writeFileSync(STATE_FILE, JSON.stringify(Array.from(set), null, 2));
}
function loadPending() {
  try {
    return JSON.parse(fs.readFileSync(PENDING_FILE, 'utf8'));
  } catch {
    return null;
  }
}
function savePending(p) {
  fs.mkdirSync(path.dirname(PENDING_FILE), { recursive: true });
  fs.writeFileSync(PENDING_FILE, JSON.stringify(p, null, 2));
}
function clearPending() {
  try { fs.unlinkSync(PENDING_FILE); } catch { /* fine */ }
}

function buildPrompt({ projectName, titles, shared, knowledgeContext }) {
  const knownStr = Object.entries(shared || {})
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');
  return `You are an expert QA engineer writing up full bug reports from just a list of short bug titles, for the project "${projectName}". ${knowledgeContext ? 'Use the trained project knowledge below to ground your guesses in the real app — its pages, modules, and terminology.' : "You don't know the real app beyond the title text, so make plausible, realistic guesses typical of that kind of bug rather than inventing suspiciously specific claims."}
${knownStr ? `\nThese fields are already set for every bug below — do NOT include them in your reply:\n${knownStr}\n` : ''}${knowledgeContext ? `\n${knowledgeContext}\n` : ''}
For EACH title below (same order, one output object per title, title copied back exactly as given), fill in whichever of these aren't already set above:
- severity: Low, Medium, High, or Critical
- page: the specific app page/screen this bug most likely occurs on
- module: a plausible feature area/module name
- sub_module: a more specific sub-area within that module
- description: 1-2 sentence overview of the bug
- steps_to_reproduce: brief numbered-style steps as a single string
- expected_result: what should happen
- actual_result: what happens instead

Respond with ONLY a JSON array, no prose, no markdown fences:
[{"title": "...", "severity": "Low"|"Medium"|"High"|"Critical", "page": "...", "module": "...", "sub_module": "...", "description": "...", "steps_to_reproduce": "...", "expected_result": "...", "actual_result": "..."}]

Bug titles:
"""
${titles.join('\n')}
"""`;
}

let lastNotesContent = null;
let lastReplyContent = null;
let supabase, user;
let ticking = false;
let reporterName = null; // resolved once in main(), from profiles.display_name

// Same trailing-number-increment scheme as the dashboard's own
// nextBugIdSuggestion() in public/app.js, so AI-logged bugs slot into the
// same numbering a human would get from the "Add bug" form
// (e.g. "BUG-001" -> "BUG-002", "PLAPLE-7" -> "PLAPLE-8").
function incrementBugId(id) {
  if (!id) return 'BUG-001';
  const m = id.match(/^(.*?)(\d+)(\D*)$/);
  if (!m) return 'BUG-001';
  const [, prefix, digits, suffix] = m;
  const next = String(parseInt(digits, 10) + 1).padStart(digits.length, '0');
  return `${prefix}${next}${suffix}`;
}

async function getLastBugId(projectId) {
  const { data, error } = await supabase
    .from('bugs')
    .select('bug_id')
    .eq('project_id', projectId)
    .order('created_at', { ascending: true });
  if (error || !data) return null;
  for (let i = data.length - 1; i >= 0; i--) {
    if (data[i].bug_id) return data[i].bug_id;
  }
  return null;
}

async function getReporterName() {
  const { data } = await supabase
    .from('profiles')
    .select('display_name, email')
    .eq('id', user.id)
    .maybeSingle();
  return (data && (data.display_name || data.email)) || user.email || 'Dashboard Notes (AI draft)';
}

async function readQuickNotes() {
  const { data, error } = await supabase
    .from('quick_notes')
    .select('notes_content, ai_reply_content')
    .eq('owner_id', user.id)
    .maybeSingle();
  if (error) throw new Error(`Reading quick_notes failed: ${error.message}`);
  return data || { notes_content: '', ai_reply_content: '' };
}

async function writeAiReplyPlaceholder(text) {
  const { error } = await supabase
    .from('quick_notes')
    .upsert({ owner_id: user.id, ai_reply_content: text, updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
  if (error) console.error(`Failed to reset AI reply box: ${error.message}`);
  lastReplyContent = text;
}

async function processNotes(content) {
  const blocks = parseNotesFile(content);
  const processed = loadProcessed();
  const newBlocks = blocks.filter((b) => !processed.has(b.id));
  if (newBlocks.length === 0) return;

  console.log(`Found ${newBlocks.length} new block(s) in the dashboard's Quick Notes box. Syncing...`);
  let pendingBlockId = null;

  for (const block of newBlocks) {
    try {
      if (block.type === 'PROJECT') {
        const result = await handleProjectBlock({ supabase, user, fields: block.fields });
        console.log(`✓ Project ${result.action}: ${result.name}`);
        processed.add(block.id);
        continue;
      }
      if (block.type !== 'BUG') continue;

      const needsAi = blockNeedsAi(block.fields);

      if (needsAi && !PAID_AI) {
        const pending = loadPending();
        if (pending) {
          console.log(`⏳ Still waiting on a previous AI reply (${pending.titles.join(', ')}) — paste it into the dashboard's "AI reply" box and save first.`);
          pendingBlockId = pending.blockId;
          continue;
        }
        const projectName = block.fields.project;
        let projectId;
        try {
          projectId = await findProjectIdByName(supabase, projectName);
        } catch (err) {
          console.error(`✗ BUG block skipped: ${err.message}`);
          continue;
        }
        if (!projectId) {
          console.error(`✗ BUG block skipped: No project named "${projectName}" exists yet. Add a PROJECT block first.`);
          continue;
        }
        const shared = getSharedBugFields(block.fields);
        const titles = block.fields.titles || [];
        const knowledgeContext = await fetchKnowledgeContext({ supabase, projectId, focusHint: shared.page || shared.module });
        const prompt = buildPrompt({ projectName, titles, shared, knowledgeContext });

        try {
          await copyToClipboard(prompt);
          console.log('📋 Prompt copied to your clipboard.');
        } catch {
          console.log('⚠ Could not auto-copy — here is the prompt:\n' + prompt);
        }
        openBrowser('https://claude.ai/new');

        await writeAiReplyPlaceholder(
          `Paste Claude's JSON reply below this line, then click "Save reply" on the dashboard.\n` +
          `(Prompt for "${titles.join('", "')}" was copied to your clipboard, Claude.ai should have opened.)\n` +
          `------------------------------------------------------------\n\n`
        );
        savePending({ blockId: block.id, projectId, projectName, titles, shared, createdAt: Date.now() });
        pendingBlockId = block.id;
        console.log('📝 Waiting for the AI reply in the dashboard\'s "AI reply" box.\n');
        continue; // not marked processed yet — waiting on the reply
      }

      const { results, errors: bugErrors } = await handleBugBlock({ supabase, user, fields: block.fields });
      for (const r of results) {
        console.log(`✓ Bug logged: "${r.title}" → ${r.project}${r.aiFilled ? ' (AI-filled fields)' : ''}`);
      }
      for (const e of bugErrors) {
        console.error(`✗ Bug "${e.title}" failed: ${e.message}`);
      }
      processed.add(block.id);
    } catch (err) {
      console.error(`✗ ${block.type} block skipped: ${err.message}`);
    }
  }

  saveProcessed(processed);

  // Clear the box once every block is either fully synced, or safely
  // waiting on a pending AI reply (which is tracked separately and
  // doesn't need the original text to stay visible). Leave the box
  // alone if something genuinely failed, so it's visible to fix.
  const stillOutstanding = blocks.some((b) => !processed.has(b.id) && b.id !== pendingBlockId);
  if (!stillOutstanding) {
    const { error } = await supabase
      .from('quick_notes')
      .upsert({ owner_id: user.id, notes_content: '', updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
    if (!error) {
      lastNotesContent = '';
      console.log('🧹 Quick Notes box cleared.\n');
    }
  }
}

async function processReply(content) {
  const pending = loadPending();
  if (!pending) return;

  const markerIdx = content.indexOf('---');
  const afterMarker = markerIdx !== -1 ? content.slice(content.indexOf('\n', markerIdx) + 1) : content;
  const text = afterMarker.trim();
  if (!text) return;

  let parsed;
  try {
    const start = text.indexOf('[');
    if (start === -1) throw new Error('no JSON array found');
    const jsonText = text.slice(start).replace(/```json/gi, '').replace(/```/g, '').trim();
    parsed = JSON.parse(jsonText);
  } catch (err) {
    console.warn(`Couldn't read the AI reply yet (${err.message}) — paste the full JSON reply (from "[" to "]") and save again.`);
    return;
  }
  if (!Array.isArray(parsed)) {
    console.warn('AI reply box doesn\'t contain a JSON array — paste Claude\'s full reply and save again.');
    return;
  }

  const byTitle = {};
  parsed.forEach((o) => { if (o && o.title) byTitle[String(o.title).trim().toLowerCase()] = o; });

  const stillMissing = [];
  let loggedAny = false;
  const todayStr = new Date().toISOString().slice(0, 10);
  let lastBugId = await getLastBugId(pending.projectId);
  const reportedBy = reporterName || (await getReporterName());

  for (const title of pending.titles) {
    const match = byTitle[title.trim().toLowerCase()];
    if (!match) { stillMissing.push(title); continue; }

    let severity = (pending.shared && pending.shared.severity) || match.severity || 'Medium';
    if (!VALID_SEVERITIES.includes(severity)) severity = 'Medium';

    const shared = pending.shared || {};
    const bugId = incrementBugId(lastBugId);
    const row = {
      owner_id: user.id,
      project_id: pending.projectId,
      bug_id: bugId,
      title,
      page: shared.page || match.page || 'Unknown',
      severity,
      status: 'Open',
      description: shared.description || match.description || null,
      module: shared.module || match.module || null,
      sub_module: shared.subModule || match.sub_module || match.subModule || null,
      steps_to_reproduce: shared.steps || match.steps_to_reproduce || null,
      expected_result: shared.expected || match.expected_result || null,
      actual_result: shared.actual || match.actual_result || null,
      reported_by: reportedBy,
      reported_date: todayStr,
      notes: shared.notes || null,
      developer_status: 'Not Started',
      retest_status: 'Not Retested',
    };

    const { error } = await supabase.from('bugs').insert(row);
    if (error) {
      console.error(`✗ Failed to log "${title}": ${error.message}`);
      stillMissing.push(title);
      continue;
    }
    lastBugId = bugId;
    console.log(`✓ Bug logged (from AI reply): "${title}" [${bugId}] → ${pending.projectName}`);
    loggedAny = true;
  }

  if (stillMissing.length) {
    if (loggedAny) console.warn(`⚠ Still missing/failed: ${stillMissing.join(', ')} — save an updated reply.`);
    savePending({ ...pending, titles: stillMissing });
    return;
  }

  clearPending();
  const processed = loadProcessed();
  processed.add(pending.blockId);
  saveProcessed(processed);

  const { error: clearErr } = await supabase
    .from('quick_notes')
    .upsert({ owner_id: user.id, ai_reply_content: '', updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
  if (!clearErr) lastReplyContent = '';

  console.log('✅ All titles from that AI reply are now logged.\n');
}

function buildTcPrompt(projectName, documentText, knowledgeContext) {
  return `You are an expert QA test case writer preparing test cases for real-world, production use — as if a market end user will actually use this feature. Based on the requirements/document text below for the project "${projectName || 'this project'}", generate a THOROUGH, comprehensive set of manual test cases.
${knowledgeContext ? `\nThe project has also been trained with the following knowledge — use it to ground test cases in the real app (its applications/modules, roles, terminology, and any functionality it describes beyond just the document below):\n${knowledgeContext}\n` : ''}
You must cover these categories as relevant, not just the happy path — spread the test cases across them realistically based on what the document supports:
- Functional — each distinct feature or requirement verified individually
- Positive — valid inputs, normal expected usage, typical end-user flows
- Negative — invalid inputs, wrong formats, missing required fields, unauthorized access, error handling
- Edge Case — boundary values, empty/null inputs, maximum length/limits, special characters, duplicate submissions, concurrent actions
- Security — auth bypass attempts, injection, data exposure, permission checks, session handling
- Validation — field-level input validation, format checks, required-field enforcement
- UI/UX — layout, responsiveness, clarity of feedback/errors, navigation flow
- Performance — load times, behavior under slow/no network, large data sets
- Accessibility — screen reader support, keyboard navigation, color contrast, labels
- Compatibility — different devices, browsers, OS versions, screen sizes
- Regression — verifying existing related functionality still works after this change
- UAT — end-to-end scenarios matching real acceptance criteria a client/user would check

Respond with ONLY a JSON array, no prose, no markdown fences, in this exact shape:
[{"title": "short test case title", "description": "steps or scenario to verify, 1-3 sentences", "priority": "Low"|"Medium"|"High", "category": "Functional"|"Positive"|"Negative"|"Edge Case"|"Security"|"Validation"|"UI/UX"|"Performance"|"Accessibility"|"Compatibility"|"Regression"|"UAT"}]

Aim for thorough coverage — typically 20-40 test cases depending on document size and complexity — distributed across the categories that are actually relevant to this document (not every category applies to every feature). Keep titles concise and descriptions actionable.

Document:
"""
${documentText}
"""`;
}

const VALID_PRIORITIES = ['Low', 'Medium', 'High'];
const VALID_CATEGORIES = [
  'Functional', 'Positive', 'Negative', 'Edge Case', 'Security',
  'Validation', 'UI/UX', 'Performance', 'Accessibility',
  'Compatibility', 'Regression', 'UAT',
];

function tryParseTestCasesJson(raw) {
  let text = raw.trim();
  text = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  const start = text.indexOf('[');
  if (start === -1) return null;
  text = text.slice(start);
  try {
    return JSON.parse(text);
  } catch { /* fall through */ }

  let depth = 0, inString = false, escape = false, lastGoodEnd = -1;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (escape) { escape = false; continue; }
    if (ch === '\\') { escape = true; continue; }
    if (ch === '"') { inString = !inString; continue; }
    if (inString) continue;
    if (ch === '{') depth++;
    if (ch === '}') { depth--; if (depth === 0) lastGoodEnd = i; }
  }
  if (lastGoodEnd !== -1) {
    try { return JSON.parse(text.slice(0, lastGoodEnd + 1) + ']'); } catch { /* give up */ }
  }
  return null;
}

let lastTcDocContent = null;
let lastTcReplyContent = null;

async function readTcQuickDoc() {
  const { data, error } = await supabase
    .from('quick_notes')
    .select('tc_project_id, tc_document_content, tc_ai_reply_content')
    .eq('owner_id', user.id)
    .maybeSingle();
  if (error) throw new Error(`Reading tc quick-doc failed: ${error.message}`);
  return data || { tc_project_id: null, tc_document_content: '', tc_ai_reply_content: '' };
}

async function writeTcReplyPlaceholder(text) {
  const { error } = await supabase
    .from('quick_notes')
    .upsert({ owner_id: user.id, tc_ai_reply_content: text, updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
  if (error) console.error(`Failed to reset TC AI reply box: ${error.message}`);
  lastTcReplyContent = text;
}

async function processTcDocument(projectId, documentText) {
  if (!documentText || !documentText.trim()) return;
  if (!projectId) {
    console.error('✗ Test-case document has no project selected on the dashboard — select a project in the Test Execution tab, re-save the document, and try again.');
    return;
  }
  if (loadTcPending()) {
    console.log('⏳ Still waiting on a previous test-case AI reply — paste it into the dashboard\'s test-case "AI reply" box and save first.');
    return;
  }

  const { data: project, error: projErr } = await supabase.from('projects').select('name').eq('id', projectId).maybeSingle();
  if (projErr) { console.error(`✗ Could not look up project: ${projErr.message}`); return; }
  const projectName = project ? project.name : '';
  const knowledgeContext = await fetchKnowledgeContext({ supabase, projectId });

  const prompt = buildTcPrompt(projectName, documentText, knowledgeContext);
  try {
    await copyToClipboard(prompt);
    console.log('📋 Test-case prompt copied to your clipboard.');
  } catch {
    console.log('⚠ Could not auto-copy — here is the prompt:\n' + prompt);
  }
  openBrowser('https://claude.ai/new');

  await writeTcReplyPlaceholder(
    `Paste Claude's JSON reply below this line, then click "Save reply" on the dashboard.\n` +
    `(Test-case prompt was copied to your clipboard, Claude.ai should have opened.)\n` +
    `------------------------------------------------------------\n\n`
  );
  saveTcPending({ projectId, projectName, documentContent: documentText, createdAt: Date.now() });
  console.log('📝 Waiting for the AI reply in the dashboard\'s test-case "AI reply" box.\n');

  const { error: clearErr } = await supabase
    .from('quick_notes')
    .upsert({ owner_id: user.id, tc_document_content: '', updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
  if (!clearErr) {
    lastTcDocContent = '';
    console.log('🧹 Test-case document box cleared.\n');
  }
}

async function processTcReply(content) {
  const pending = loadTcPending();
  if (!pending) return;

  const markerIdx = content.indexOf('---');
  const afterMarker = markerIdx !== -1 ? content.slice(content.indexOf('\n', markerIdx) + 1) : content;
  const text = afterMarker.trim();
  if (!text) return;

  const parsed = tryParseTestCasesJson(text);
  if (!parsed || !Array.isArray(parsed) || !parsed.length) {
    console.warn('Couldn\'t read the test-case AI reply yet — paste the full JSON reply (from "[" to "]") and save again.');
    return;
  }

  const rows = parsed
    .filter((t) => t && t.title)
    .map((t) => ({
      project_id: pending.projectId,
      title: String(t.title).slice(0, 200),
      description: t.description ? String(t.description).slice(0, 1000) : null,
      priority: VALID_PRIORITIES.includes(t.priority) ? t.priority : 'Medium',
      category: VALID_CATEGORIES.includes(t.category) ? t.category : 'Functional',
      status: 'Not Run',
      owner_id: user.id,
    }));

  if (!rows.length) {
    console.warn('No valid test cases found in that reply.');
    return;
  }

  const { error } = await supabase.from('test_cases').insert(rows);
  if (error) {
    console.error(`✗ Failed to log test cases: ${error.message}`);
    return;
  }

  console.log(`✓ Added ${rows.length} AI-generated test case(s) to "${pending.projectName}".\n`);
  clearTcPending();

  const { error: clearErr } = await supabase
    .from('quick_notes')
    .upsert({ owner_id: user.id, tc_ai_reply_content: '', updated_at: new Date().toISOString() }, { onConflict: 'owner_id' });
  if (!clearErr) lastTcReplyContent = '';
}

const TC_PENDING_FILE = path.join(__dirname, '..', 'state', 'pending-tc-block-dashboard.json');

function loadTcPending() {
  try {
    return JSON.parse(fs.readFileSync(TC_PENDING_FILE, 'utf8'));
  } catch {
    return null;
  }
}
function saveTcPending(p) {
  fs.mkdirSync(path.dirname(TC_PENDING_FILE), { recursive: true });
  fs.writeFileSync(TC_PENDING_FILE, JSON.stringify(p, null, 2));
}
function clearTcPending() {
  try { fs.unlinkSync(TC_PENDING_FILE); } catch { /* fine */ }
}

async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    let { notes_content, ai_reply_content } = await readQuickNotes();

    if (notes_content !== lastNotesContent) {
      lastNotesContent = notes_content;
      await processNotes(notes_content || '');
      // processNotes may have just overwritten ai_reply_content (e.g. with
      // a fresh "paste here" placeholder) via writeAiReplyPlaceholder.
      // Re-read so the comparison below reflects that, not the value we
      // fetched before processNotes ran — otherwise we'd end up parsing
      // whatever old/unrelated text happened to be sitting in that column
      // beforehand and print a confusing "couldn't read that reply" warning.
      ({ ai_reply_content } = await readQuickNotes());
    }
    if (ai_reply_content !== lastReplyContent) {
      lastReplyContent = ai_reply_content;
      await processReply(ai_reply_content || '');
    }

    let { tc_project_id, tc_document_content, tc_ai_reply_content } = await readTcQuickDoc();

    if (tc_document_content !== lastTcDocContent) {
      lastTcDocContent = tc_document_content;
      await processTcDocument(tc_project_id, tc_document_content || '');
      ({ tc_ai_reply_content } = await readTcQuickDoc());
    }
    if (tc_ai_reply_content !== lastTcReplyContent) {
      lastTcReplyContent = tc_ai_reply_content;
      await processTcReply(tc_ai_reply_content || '');
    }
  } catch (err) {
    console.error('Error checking dashboard notes:', err.message);
  } finally {
    ticking = false;
  }
}

async function main() {
  console.log('Logging into Supabase...');
  const auth = await getAuthedSupabase();
  supabase = auth.supabase;
  user = auth.user;
  console.log(`Signed in as ${user.email}`);
  reporterName = await getReporterName();
  console.log(`Bugs will be logged with "Reported By" = ${reporterName}`);
  console.log(`Watching the dashboard's Quick Notes + Test Case boxes (polling every ${POLL_MS / 1000}s)...`);
  console.log('Bugs tab: write a ### BUG / ### PROJECT block in "Quick Notes", click "Save notes".');
  console.log('Test Execution tab: paste requirements into the quick-doc box, click "Save document".\n');

  await tick();
  setInterval(tick, POLL_MS);
}

main().catch((err) => {
  console.error('Fatal error:', err.message);
  process.exit(1);
});
