require('dotenv').config();

const ENABLE_AI = String(process.env.ENABLE_AI_AUTOFILL || '').toLowerCase() === 'true';
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.AI_MODEL || 'claude-haiku-4-5-20251001';

/**
 * Asks Claude to guess reasonable bug-report fields from just a title
 * (and whatever else is already known). Returns {} on any failure or
 * if AI autofill is disabled — callers should treat every field as
 * optional and fall back to their own defaults.
 */
async function aiFillBugFields({ title, projectName, known, knowledgeContext }) {
  if (!ENABLE_AI) return {};
  if (!API_KEY) {
    console.warn(
      `ENABLE_AI_AUTOFILL is true but ANTHROPIC_API_KEY is missing in .env — skipping AI autofill for "${title}".`
    );
    return {};
  }

  const knownStr = Object.entries(known || {})
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');

  const prompt = `You are helping a QA tester flesh out a bug report from just a short title. ${knowledgeContext ? 'Use the trained project knowledge below to ground your guesses in the real app — its pages, modules, and terminology.' : "Make reasonable, plausible guesses typical of this kind of bug — you don't know the real app, so keep guesses generic rather than inventing suspiciously specific details."}

Project: ${projectName}
Bug title: "${title}"
${knownStr ? `Fields already provided by the tester (leave these out of your answer, they're already set):\n${knownStr}\n` : ''}${knowledgeContext ? `\n${knowledgeContext}\n` : ''}
Respond with ONLY a JSON object, no other text, no markdown code fences, with exactly these keys (use "" for any you can't reasonably guess):
{"severity": "Low|Medium|High|Critical", "module": "", "description": "", "steps_to_reproduce": "", "expected_result": "", "actual_result": ""}`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.warn(`AI autofill request failed (${res.status}) for "${title}": ${text.slice(0, 200)}`);
      return {};
    }

    const data = await res.json();
    const textBlock = (data.content || []).find((b) => b.type === 'text');
    if (!textBlock) return {};

    const cleaned = textBlock.text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (err) {
    console.warn(`AI autofill error for "${title}": ${err.message}`);
    return {};
  }
}

module.exports = { aiFillBugFields, ENABLE_AI };
