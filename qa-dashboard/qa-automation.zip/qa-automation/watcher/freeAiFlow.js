require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { fetchKnowledgeContext } = require('../lib/projectKnowledge');

const PENDING_FILE = path.join(__dirname, '..', 'state', 'pending-ai-block.json');
const REPLY_FILE_PATH = process.env.AI_REPLY_FILE_PATH;
const VALID_SEVERITIES = ['Low', 'Medium', 'High', 'Critical'];

// --- Windows-only helpers (matches the environment this was built for) ---
function copyToClipboard(text) {
  return new Promise((resolve, reject) => {
    const proc = exec('clip', (err) => (err ? reject(err) : resolve()));
    proc.stdin.write(text);
    proc.stdin.end();
  });
}

function openBrowser(url) {
  exec(`start "" "${url}"`, (err) => {
    if (err) console.warn(`Could not auto-open a browser tab: ${err.message}. Open ${url} manually.`);
  });
}
// ---------------------------------------------------------------------

function loadPending() {
  try {
    return JSON.parse(fs.readFileSync(PENDING_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function savePending(pending) {
  fs.mkdirSync(path.dirname(PENDING_FILE), { recursive: true });
  fs.writeFileSync(PENDING_FILE, JSON.stringify(pending, null, 2));
}

function clearPending() {
  try {
    fs.unlinkSync(PENDING_FILE);
  } catch {
    /* already gone, fine */
  }
}

function buildPrompt({ projectName, titles, shared, knowledgeContext }) {
  const knownStr = Object.entries(shared || {})
    .filter(([, v]) => v)
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n');

  return `You are an expert QA engineer writing up full bug reports from just a list of short bug titles, for the project "${projectName}". ${knowledgeContext ? 'Use the trained project knowledge below to ground your guesses in the real app — its pages, modules, and terminology.' : "You don't know the real app beyond the title text, so make plausible, realistic guesses typical of that kind of bug rather than inventing suspiciously specific claims."}
${knownStr ? `\nThese fields are already set for every bug below — do NOT include them in your reply:\n${knownStr}\n` : ''}${knowledgeContext ? `\n${knowledgeContext}\n` : ''}
For EACH title below (same order, one output object per title, title copied back exactly as given), fill in whichever of these aren't already set above:
- severity: Low, Medium, High, or Critical
- module: a plausible feature area/module name
- description: 1-2 sentence overview of the bug
- steps_to_reproduce: brief numbered-style steps as a single string
- expected_result: what should happen
- actual_result: what happens instead

Respond with ONLY a JSON array, no prose, no markdown fences:
[{"title": "...", "severity": "Low"|"Medium"|"High"|"Critical", "module": "...", "description": "...", "steps_to_reproduce": "...", "expected_result": "...", "actual_result": "..."}]

Bug titles:
"""
${titles.join('\n')}
"""`;
}

async function startFreeAiFlow({ blockId, projectId, projectName, titles, shared, supabase }) {
  if (!REPLY_FILE_PATH) {
    console.warn('FREE_AI_FLOW is on but AI_REPLY_FILE_PATH is not set in .env — skipping AI help for this block, fields will stay blank.');
    return false;
  }

  const knowledgeContext = supabase
    ? await fetchKnowledgeContext({ supabase, projectId, focusHint: (shared && (shared.page || shared.module)) || '' })
    : '';
  const prompt = buildPrompt({ projectName, titles, shared, knowledgeContext });

  try {
    await copyToClipboard(prompt);
    console.log('\n📋 Prompt copied to your clipboard.');
  } catch {
    console.log('\n⚠ Could not auto-copy — paste this into Claude.ai manually:\n');
    console.log(prompt);
  }

  openBrowser('https://claude.ai/new');

  const instructions =
    `Paste Claude's JSON reply below this line, then save this file.\n` +
    `(Prompt for "${titles.join('", "')}" was copied to your clipboard, Claude.ai should have opened.)\n` +
    `------------------------------------------------------------\n\n`;
  fs.mkdirSync(path.dirname(REPLY_FILE_PATH), { recursive: true });
  fs.writeFileSync(REPLY_FILE_PATH, instructions);

  savePending({ blockId, projectId, projectName, titles, shared, createdAt: Date.now() });

  console.log(`📝 Paste Claude's reply into: ${REPLY_FILE_PATH}`);
  console.log('   Save it once pasted — this window will pick it up automatically.\n');

  return true;
}

/**
 * Call this whenever the reply file changes. Returns:
 *   null              — nothing to do (no pending block, or nothing pasted yet)
 *   { blockId, done }  — done=true means every title got a match and the
 *                        pending record was cleared; done=false means some
 *                        titles are still waiting (pending record updated
 *                        to just those).
 */
async function tryFinalizePendingReply({ supabase, user }) {
  const pending = loadPending();
  if (!pending) return null;
  if (!REPLY_FILE_PATH || !fs.existsSync(REPLY_FILE_PATH)) return null;

  const raw = fs.readFileSync(REPLY_FILE_PATH, 'utf8');
  const markerIdx = raw.indexOf('---');
  const afterMarker = markerIdx !== -1 ? raw.slice(raw.indexOf('\n', markerIdx) + 1) : raw;
  const text = afterMarker.trim();
  if (!text) return null; // nothing pasted below the line yet

  let parsed;
  try {
    const start = text.indexOf('[');
    if (start === -1) throw new Error('no JSON array found');
    const jsonText = text
      .slice(start)
      .replace(/```json/gi, '')
      .replace(/```/g, '')
      .trim();
    parsed = JSON.parse(jsonText);
  } catch (err) {
    console.warn(`Couldn't read that reply yet (${err.message}) — paste the full JSON reply (from "[" to "]") and save again.`);
    return null;
  }
  if (!Array.isArray(parsed)) {
    console.warn('That reply isn\'t a JSON array — paste Claude\'s full reply and save again.');
    return null;
  }

  const byTitle = {};
  parsed.forEach((o) => {
    if (o && o.title) byTitle[String(o.title).trim().toLowerCase()] = o;
  });

  const stillMissing = [];
  let loggedAny = false;

  for (const title of pending.titles) {
    const match = byTitle[title.trim().toLowerCase()];
    if (!match) {
      stillMissing.push(title);
      continue;
    }

    let severity = (pending.shared && pending.shared.severity) || match.severity || 'Medium';
    if (!VALID_SEVERITIES.includes(severity)) severity = 'Medium';

    const shared = pending.shared || {};
    const row = {
      owner_id: user.id,
      project_id: pending.projectId,
      title,
      page: shared.page || 'Unknown',
      severity,
      status: 'Open',
      description: shared.description || match.description || null,
      module: shared.module || match.module || null,
      sub_module: shared.subModule || null,
      steps_to_reproduce: shared.steps || match.steps_to_reproduce || null,
      expected_result: shared.expected || match.expected_result || null,
      actual_result: shared.actual || match.actual_result || null,
      reported_by: 'Notes Import (AI draft)',
      notes: shared.notes || null,
      developer_status: 'Not Started',
      retest_status: 'Not Retested',
    };

    const { error } = await supabase.from('bugs').insert(row);
    if (error) {
      console.error(`✗ Failed to log "${title}": ${error.message}`);
      stillMissing.push(title); // retry next time, don't lose it
      continue;
    }
    console.log(`✓ Bug logged (from AI reply): "${title}" → ${pending.projectName}`);
    loggedAny = true;
  }

  if (stillMissing.length) {
    if (loggedAny) {
      console.warn(`⚠ Reply is missing/failed for: ${stillMissing.join(', ')} — still waiting, add these to a fresh reply and save again.`);
    }
    savePending({ ...pending, titles: stillMissing });
    return { blockId: pending.blockId, done: false };
  }

  clearPending();
  return { blockId: pending.blockId, done: true };
}

module.exports = { startFreeAiFlow, loadPending, clearPending, tryFinalizePendingReply, REPLY_FILE_PATH };
